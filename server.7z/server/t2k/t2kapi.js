/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(['./t2kapi.logger', './t2kapi.server', './t2kapi.model', './t2kapi.db', './t2kapi.iterator', './t2kapi.aes'],
function(Logger, Server, Model, DB, Iterator, AES) {

	var Module = {};

	var serverTimeDelay = 0;

	var ErrorType = {
		NotAuthorized: "NotAuthorized",
		ServerOffline: "ServerOffline",
		ServerError: "ServerError",
		NoData: "NoData",
		TemporaryPasswordError: "TemporaryPasswordError"
	};

	var NotificationType = {
		AuthorizationFailed: "AuthorizationFailed",
		ServerOnlineState: "ServerOnlineState"
	};

	var initialize = function() {
		Logger.d('api', 'api is initializing');
		DB.init();
		Server.init();
		Server.onChangeState(onServerChangeState);
		for (var moduleName in Module) {
			if (typeof(Module[moduleName].init) === 'function') {
				Logger.d('api', 'initializing module $$', moduleName);
				Module[moduleName].init.apply(Module[moduleName]);
			}
		}
		Logger.d('api', 'api is ready');
		triggerEvent('t2kapi:ready', { api: T2kApi });
	};

	var onServerChangeState = function(online) {
		Module.notification.trigger(NotificationType.ServerOnlineState, online);
	};

	var triggerEvent = function(eventName, data) {
		var evt = document.createEvent('CustomEvent');
		evt.initEvent(eventName, true, false);
		evt.data = data;
		document.dispatchEvent(evt);
	};

	var exec = function (success, error, module, method, args) {
		var request,
			response;

		if (Module[module] && Module[module][method]) {
			request = {
				name: method,
				forward: function(){ Module[module][method].apply(Module[module], args); }
			};
			response = {
				success: success || function(){},
				error: error || function(){}
			};
			Logger.d('api', 'executing method: $$ on $$', method, module);
			args.push(response);
			if (Module[module]['before_filter']) {
				Module[module]['before_filter'].apply(Module[module], [request, response]);
			} else {
				request.forward();
			}
		} else {
			Logger.e('api', 'method $$ at module $$ is not implemented yet', method, module);
		}
	};

	var getTime = function() {
		return (new Date()).getTime() - serverTimeDelay;
	};

	var has = function(arr, params) {
		var found;
		for (var i = 0; (arr && arr.length && i < arr.length); i++) {
			found = true;
			for (var key in params) {
				if (arr[i][key] !== params[key]) {
					found = false;
				}
			}
			if (found) {
				return arr[i];
			}
		}
		return null;
	};

	var isEmptyArray = function(arr) {
		return (!arr || (arr.length == 0));
	};

	var generateUID = function() {
		var uuid = "", i, random;
		for (i = 0; i < 32; i++) {
			random = Math.random() * 16 | 0;
			if (i == 8 || i == 12 || i == 16 || i == 20) {
				uuid += "-"
			}
			uuid += (i == 12 ? 4 : (i == 16 ? (random & 3 | 8) : random)).toString(16);
		}
		return uuid;
	};

	// avoid use of underscore
	var _ = {};

	/*
	* Authorization Module
	*
	*/
	Module.auth = {

		SESSION_KEY: 't2ksessionid',
		encryption_key: '123456',

		init: function() {
			Module.notification.addObserver(this, this.onServerChangeState, NotificationType.ServerOnlineState);
			this.removeSession();
		},

		check_auth: function(callback) {
			var self = this,
				session = this.getSession();
			if (session) {
				callback(true);
			} else {
				callback(false);
			}
		},

		onServerChangeState: function(online) {
			var self = this,
				session = this.getSession();

			if (online && session) {
				Server.get(Module.server.casWebappUrl + '/amIUser', {}, {
					xhrFields: {withCredentials: true},
					crossDomain: true,
					data: {"username": session.username},
					dataType: "json",
					forceOffline: true,
					success: function(response) {
						if (response.isSameUser.toLowerCase() !== "true") {
							self.establishConnection(session.username);
						}
					},
					error: function() {
						self.establishConnection(session.username);
					}
				});
			}
		},

		establishConnection: function(username) {
			var self = this;
			Server.establishingConnection(true);
			this.logout({
				success: function() {
					Model('user').where({username: username}).get(function(user) {
						if (user && user.secret) {
							var pass = AES.dec(user.secret, self.encryption_key);
							self.login(username, pass, {
								success: function(){
									Server.establishingConnection(false);
								},
								error: function() { 
									self.removeSession();
									Server.establishingConnection(false);
								}
							});
						} else {
							self.removeSession();
							Server.establishingConnection(false);
						}
					});			
				}
			});
		},

		createSession: function(username) {
			var session_value = username + '@@' + (new Date()).getTime();
			window.localStorage.setItem(this.SESSION_KEY, AES.enc(session_value, this.encryption_key));
		},

		getSession: function() {
			var session_enc = window.localStorage.getItem(this.SESSION_KEY),
				session_value,
				sessionData;
			if (session_enc) {
				session_value = AES.dec(session_enc, this.encryption_key);
				sessionData = session_value.split('@@');
				return {
					username: sessionData[0],
					timestamp: Number(sessionData[1])
				};
			}
			return null;
		},

		removeSession: function() {
			window.localStorage.removeItem(this.SESSION_KEY);
		},

		loginSuccessHandler: function(username, secret, response) {
			var self = this;
			Model('user').where({username: username, data: {
				username: username,
				secret: secret
			}}).save();
			self.createSession(username);
			response.success({username: username});
		},

		offlineLogin: function(username, secret, response) {
			var self = this;
			Model('user').where({username: username}).get(function(user) {
				if ((user) && (AES.dec(user.secret, self.encryption_key) === AES.dec(secret, self.encryption_key))) {
					self.createSession(username);
					Module.notification.trigger(NotificationType.ServerOnlineState, false);
					response.success(user);
				} else {
					self.removeSession();
					response.error({type: ErrorType.NotAuthorized});
				}
			});
		},

		changePassword: function(username, oldpassword, newpassword, response) {
			Server.save('rest/ext/users/changepassword', {
					data: {
						username: username,
						oldPassword: oldpassword,
						newPassword: newpassword
					}
				},
				{
				type: 'post',
				success: response.success,
				error: function(){
					response.error({type: ErrorType.ServerError});
				},
				offline: function(){
					response.error({type: ErrorType.ServerOffline});
				}
			});
		},

		login: function(username, password, response) {
			var self = this,
				secret = AES.enc(password, self.encryption_key);
			Server.get(Module.server.casWebappUrl + '/login', {}, {
				crossDomain: true,
				xhrFields: {withCredentials: true},
				forceOffline: true,
				data: {t2kLoginMode: "rest",  service: Module.server.casService, username: username, password: password},
				success: function(res) {
					var ticket = res.st;
					if (ticket) {
						Server.get('external-login.js', {}, {
							data: {ticket: ticket, redirectAfterValidation: "false" },
							xhrFields: {withCredentials: true},
							crossDomain: true,
							dataType: "text",
							forceOffline: true,
							success: function() {
								self.loginSuccessHandler(username, secret, response);
							},
							error: function(jqXHR) {
								response.error({type: ErrorType.NotAuthorized});
							},
							offline: function() {
								self.offlineLogin(username, secret, response);
							}
						});
					} else {
						response.error({type: ErrorType.NotAuthorized});
					}
				},
				error: function(jqXHR) {
					try {
						var errorObj = JSON.parse(jqXHR.responseText);
						if (errorObj.error.search('password expired') !== -1) {
							response.error({type: ErrorType.TemporaryPasswordError});
						} else {
							response.error({type: ErrorType.NotAuthorized});
						}
					} catch (ex) {
						response.error({type: ErrorType.NotAuthorized});
					}
				},
				offline: function() {
					self.offlineLogin(username, secret, response);
				}
			});
		},

		logout: function(response) {
			var self = this;
			Server.get(Module.server.casWebappUrl + '/logout', {}, {
				crossDomain: true,
				xhrFields: {withCredentials: true},
				data: {t2kLoginMode: "rest"},
				forceOffline: true,
				success: function(res) {
					self.removeSession();
					response.success();
				},
				error: function() {
					self.removeSession();
					response.success();
				},
				offline: function() {
					self.removeSession();
					response.success();
				}
			});
		}
	};

	/*
	* User Data
	*
	*/
	Module.user = {

		_configurations: null,
		_school: null,
		_user: null,
		_role: null,
		_globalUserState: null,
		_roleStr: null,

		before_filter: function(request, response) {
			switch (request.name) {
				case 'login':
				case 'logout':
				case 'changePassword':
					request.forward();
				break;
				default:
					Module.auth.check_auth(function(authorized){
						if (authorized) {
							request.forward();
						} else {
							response.error({type: ErrorType.NotAuthorized});
						}
					});
			}
		},

		initData: function(response) {
			var self = this;
			var username = Module.auth.getSession().username;
			Model('appData').where({user: username}).get(function(appdata) {
				if (!appdata) {
					return response.error({type: ErrorType.ServerError});
				}
				self._configurations = appdata.configurations;
				Server.config({
					serverAjaxRetryDelay: Number(appdata.configurations.serverAjaxRetryDelay),
					serverAjaxRetries: Number(appdata.configurations.serverAjaxRetries)
				});
				serverTimeDelay = appdata.configurations.serverTime - (new Date().getTime());
				self._user = appdata.user;
				self._school = appdata.school;
				self._logoutUrl = appdata.logoutUrl;
				self._role = appdata.user.roles[0].toLowerCase();
				self._roleStr = self._role + 's';
				Module.content.flush();
				response.success(appdata);
			});
		},

		login: function(username, password, response) {
			var self = this;
			Module.auth.login(username, password, {
				success: function(user){
					self.initData(response);
				},
				error: response.error
			});
		},

		changePassword: function(username, oldpassword, newpassword, response) {
			Module.auth.changePassword(username, oldpassword, newpassword, response);
		},

		logout: function(response) {
			Module.auth.logout(response);
		},

		getConfigurations: function(response) {
			response.success(this._configurations);
		},

		getStudyClasses: function(response) {
			var self = this;
			var ret = [];
			Model('studyClasses').where({ role: self._roleStr, userId: self._user.id}).get(function(studyClasses){
				Model('classStates').where({userId: self._user.id}).get(function(classStates){
					for (var i = 0; i < studyClasses.length; i++) {
						var state = has(classStates, {studyClassId: studyClasses[i].id});
						ret.push({
							id: studyClasses[i].id,
							classTemplate: studyClasses[i].classTemplate,
							name: studyClasses[i].name,
							imageURL: '/lms/rest/schools/'+Module.user._school.id+'/images/'+studyClasses[i].imageId,
							classState: state
						});
					}
					response.success(ret);
				});
			});
		},

		getActiveLessonSession: function(response) {
			var params = {userId: Module.user._user.id};
			Model('globalUserState').where(params).get(function(globalUserState) {
				if ((!globalUserState) || (!globalUserState.rtcm)) {
					return response.success(null);
				}
				Model('classStates').where(params).get(function(classStates) {
					if (!classStates) {
						return response.success(null);
					}
					params.role = Module.user._roleStr;
					Model('studyClasses').where(params).get(function(classes) {
						if (!classes) {
							return response.success(null);
						}
						var classObj = has(classes, {id: globalUserState.rtcm.activeStudyClassId});
						var classState = has(classStates, {studyClassId: globalUserState.rtcm.activeStudyClassId})
						if (classState && classObj) {
							response.success({
								timestamp: globalUserState.rtcm.timestamp,
								studyClass: classObj,
								classState: classState,
								lessonCid: classState.rtcmSession.activeLesson.lessonCid,
								courseId: classState.courseId,
								sequenceCid: classState.rtcmSession.activeLesson.sequenceCid
							});
						} else {
							response.success(null);
						}
					});
				});
			});
		},

		setActiveLessonSession: function(classId, timestamp, response) {
			var params = { userId: Module.user._user.id };
			Model('globalUserState').where(params).get(function(globalUserState){
				if (globalUserState === null) {
					globalUserState = {
						userId: Module.user._user.id,
						schoolId: Module.user._school.id
					};
				}
				globalUserState.rtcm = {
					activeStudyClassId: Number(classId),
					timestamp: timestamp
				};
				params.data = globalUserState;
				this.where(params).save(response.success);
			});
		},

		leaveSession: function(response) {
			var params = { userId: Module.user._user.id };
			Model('globalUserState').where(params).get(function(globalUserState){
				if (globalUserState === null) {
					return response.success(null);
				}
				globalUserState.rtcm = null;
				params.data = globalUserState;
				this.where(params).save(response.success);
			});
		},

		getActiveAssessmentSession: function(response) {
			var params = {userId: Module.user._user.id};
			Model('globalUserState').where(params).get(function(globalUserState){
				if ((!globalUserState) || (!globalUserState.rtcm)) {
					return response.success(null);
				}
				Model('classStates').where(params).get(function(classStates){
					if (!classStates) {
						return response.success(null);
					}
					params.role = Module.user._roleStr;
					Model('studyClasses').where(params).get(function(classes){
						var classObj = has(classes, {id: globalUserState.rtcm.activeStudyclassId});
						var classState = has(classStates, {studyclassId: globalUserState.rtcm.activeStudyClassId});
						if (classObj && classState) {
							response.success({
								timestamp: globalUserState.rtcm.timestamp,
								studyClass: classObj,
								classState: classState,
								assessmentCid: classState.rtcmSession.activeLesson.assessmentCid,
								assessmentInstanceId: (classState.rtcmSession.activeAssessment) ? classState.rtcmSession.activeAssessment.assessmentInstanceId : null,
								courseId: classState.courseId
							});
						} else {
							response.success(null);
						}
					});
				});
			});
		},

		setActiveAssessmentSession: function(classId, timestamp, response) {
			var params = { userId: Module.user._user.id };
			Model('globalUserState').where(params).get(function(globalUserState){
				if (globalUserState === null) {
					globalUserState = {
						userId: Module.user._user.id,
						schoolId: Module.user._school.id
					};
				}
				globalUserState.rtcm = {
					activeStudyClassId: Number(classId),
					timestamp: timestamp
				};
				params.data = globalUserState;
				this.where(params).save(response.success);
			});
		},

		getAvailableSessions: function(response) {
			Model('activeSessions').where({userId: Module.user._user.id}).get(function(sessions){
				if (sessions === null || sessions.length === 0) {
					return response.success(null);
				}
				Model('classStates').where({userId: Module.user._user.id}).get(function(classStates) {
					if (!classStates) {
						return response.success(null);
					}
					Model('studyClasses').where({userId: Module.user._user.id, role: Module.user._roleStr}).get(function(studyClasses) {
						if (!studyClasses) {
							return response.success(null);
						}
						var responseObject = [];
						for (var i = 0; i < sessions.length; i++) {
							var classState;
                            for (var j = 0; j < classStates.length; j++) {
                                if ((classStates[j].studyClassId === sessions[i].studyClassId) && (classStates[j].rtcmSession) && (classStates[j].rtcmSession.sessionTimestamp === sessions[i].startTimestamp)){
                                    classState =   classStates[j];
                                    break;
                                }
                            }
							var classObj = has(studyClasses, {id: sessions[i].studyClassId});
							if (classState && classObj) {
								responseObject.push({
									assessmentInstanceId: (classState.rtcmSession.activeAssessment) ? classState.rtcmSession.activeAssessment.assessmentInstanceId : null,
									timestamp: sessions[i].startTimestamp,
									studyClass: classObj,
									classState: classState,
									courseId: classState.courseId,
									lessonCid: (classState.rtcmSession.activeLesson) ? classState.rtcmSession.activeLesson.lessonCid : null,
									sequenceCid: (classState.rtcmSession.activeLesson) ? classState.rtcmSession.activeLesson.sequenceCid : null,
									assessmentCid: (classState.rtcmSession.activeAssessment) ? classState.rtcmSession.activeAssessment.assessmentCid : null
								});
							} else {
								response.success(null);
							}
						}
						response.success(responseObject);
					});
				});
			});
		},

		getActivities: function(classId, response) {
			Model('classActivities').where({userId: Module.user._user.id, classId: Number(classId), schoolId: Module.user._school.id})
				.get(function(studentActivities){
					response.success((studentActivities && studentActivities.activities) ? studentActivities.activities : []);
				});
		},

		getConductedAssessments: function(classId, response) {
			var params = {userId: Module.user._user.id};
			Model('classStates').where(params).get(function(classStates){
				var classState = has(classStates, {studyClassId: Number(classId)}),
					res = [];
				if (classState && classState.conductedSessions) {
					for (var sessionKey in classState.conductedSessions) {
						for (var itemKey in classState.conductedSessions[sessionKey].conductedItems) {
							if (classState.conductedSessions[sessionKey].conductedItems[itemKey].type === 'assessment') {
								res.push(classState.conductedSessions[sessionKey].conductedItems[itemKey]);
							}
						}
					}

				}
				res.sort(function(i1, i2){ return i2.startTime - i1.startTime});
				response.success(res);
			});
		},

		getConductedLessons: function(classId, response) {
			var params = {userId: Module.user._user.id};
			Model('classStates').where(params).get(function(classStates){
				var classState = has(classStates, {studyClassId: Number(classId)}),
					res = [];
				if (classState && classState.conductedSessions) {
					for (var sessionKey in classState.conductedSessions) {
						for (var itemKey in classState.conductedSessions[sessionKey].conductedItems) {
							if (classState.conductedSessions[sessionKey].conductedItems[itemKey].type === 'lesson') {
								res.push(classState.conductedSessions[sessionKey].conductedItems[itemKey]);
							}
						}
					}

				}
				response.success(res);
			});
		},

		getConductedSessions: function(classId, response) {
			var params = {userId: Module.user._user.id};
			Model('classStates').where(params).get(function(classStates){
				var classState = has(classStates, {studyClassId: Number(classId)});
				var conductedSessions = (classState && classState.conductedSessions) ? classState.conductedSessions : [];
				response.success(conductedSessions);
			});
		}
	};

	/*
	* Content
	*
	*/
	Module.content = {

		classCourses: {},

		before_filter: function(request, response) {
			Module.auth.check_auth(function(authorized){
				if (authorized) {
					request.forward();
				} else {
					response.error({type: ErrorType.NotAuthorized});
				}
			});
		},

		getCourseByClass: function(classId, response) {
			var self = this;
			if (self.classCourses[classId+""]) {
				return response.success(self.classCourses[classId+""]);
			}
			Model('classStates').where({userId: Module.user._user.id}).get(function(classStates) {
				if (typeof(classStates) === 'undefined') {
					return response.error({type: ErrorType.NoData});
				}
				for (var i = 0; i < classStates.length; i++) {
					if ((classStates[i].studyClassId == Number(classId)) && (classStates[i].associated)) {
						var classState = classStates[i];
						self.getCourse(classState.courseId, {
							success: function(course) {
								self.classCourses[classId+""] = course;
								response.success(course);
							}
						});
						return;
					}
				}
				return response.error({type: ErrorType.NoData});
			});
		},

		getCourse: function(courseId, response) {
			Model('course').where({courseId: courseId}).get(function(course) {
				if (course) {
					var courseResourcePath = Module.user._configurations.courseResourcePath + '/' + course.data.cid + '/';
					course.data.courseImageURL = (course.data.resources && course.data.resources.length) ? courseResourcePath + '/' + course.data.resources[0].href : '';
				}
				response.success(course);
			});
		},

		getLessonContentForStudent: function(classId, courseId, lessonCid, response) {
			var courseLevelId;
			Model('userSequenceState').where({userId: Module.user._user.id, schoolId: Module.user._school.id, courseId: courseId, lessonCid: lessonCid}).getList(function(userStateList){
				Model('studentClassStates').where({schoolId: Module.user._school.id, classId: classId, userId: Module.user._user.id}).get(function(studentState){
					courseLevelId = studentState.differentiationLevel.levelId;
					Model('course').where({courseId: courseId}).get(function(course) {
						courseResourcePath = Module.user._configurations.courseResourcePath + '/' + course.data.cid + '/';
						Model('lessonContent').where({courseId: courseId, lessonCid: lessonCid}).get(function(lesson){
							var lessonMetaData,
								lessonIndex,
								i = 1;
							Iterator.Lesson.each(course.data.toc, function(lesson){
								if (lesson.cid === lessonCid) {
									lessonMetaData = lesson;
									lessonIndex = i;
								}
								i++;
							});
							if (lessonMetaData) {
								lessonMetaData.lessonIndex = lessonIndex;
								// attach resources to course items and filter out sequences from a different level (if student)
								if (!isEmptyArray(lesson.data.resources)) {
									Iterator.Sequence.each(lesson.data, function(sequence) {
										var thumbnailResource = has(lesson.data.resources, {resId: sequence.thumbnailRef});
										var contentResource = has(lesson.data.resources, {resId: sequence.contentRef});
										if (thumbnailResource) {
											sequence.thumbnailHref = courseResourcePath + thumbnailResource.href;
										}
										if (contentResource) {
											sequence.contentHref = courseResourcePath + contentResource.href;
										}

										if (sequence.type === "differentiatedSequenceParent") {
											var studentSequenceLevel = has(sequence.levels, {levelId: courseLevelId});
											var parentCid = sequence.cid;
											var stateFound = null,
												sequenceWithState;
											for (var level in sequence.levels) {
												stateFound = has(userStateList, {sequenceCid: sequence.levels[level].sequence.cid});
												if (stateFound) {
													sequenceWithState = sequence.levels[level].sequence;
													sequence = $.extend(sequenceWithState, {title: sequence.title, diffParentCid: sequence.cid, parentCid: parentCid});
													return sequence;
												}
											}
											sequence = $.extend(studentSequenceLevel.sequence, {title: sequence.title, diffParentCid: sequence.cid, parentCid: parentCid});
											return sequence;
										}
										return sequence;
									});
								}
								lessonMetaData.data = lesson.data;
								lessonMetaData.course = course;
								response.success(lessonMetaData);
							} else {
								response.error({type: ErrorType.NoData});
							}
						});
					});

				});
			});
		},

		getLesson: function(courseId, lessonCid, response) {
			Model('lessonContent').where({courseId: courseId, lessonCid: lessonCid}).get(response.success);
		},

		getLessonContent: function(courseId, lessonCid, response) {
			var courseResourcePath,
				studentGradeLevelId = (Module.user._user.gradeLevel) ? Module.user._user.gradeLevel.id : null;
			Model('course').where({courseId: courseId}).get(function(course) {
				courseResourcePath = Module.user._configurations.courseResourcePath + '/' + course.data.cid + '/';
				Model('lessonContent').where({courseId: courseId, lessonCid: lessonCid}).get(function(lesson){
					var lessonMetaData,
						lessonIndex,
						i = 1;
					Iterator.Lesson.each(course.data.toc, function(lesson){
						if (lesson.cid === lessonCid) {
							lessonMetaData = lesson;
							lessonIndex = i;
						}
						i++;
					});
					if (lessonMetaData) {
						lessonMetaData.lessonIndex = lessonIndex;
						// attach resources to course items and filter out sequences from a different level (if student)
						if (!isEmptyArray(lesson.data.resources)) {
							Iterator.Sequence.each(lesson.data, function(sequence) {
								var thumbnailResource = has(lesson.data.resources, {resId: sequence.thumbnailRef});
								var contentResource = has(lesson.data.resources, {resId: sequence.contentRef});
								if (thumbnailResource) {
									sequence.thumbnailHref = courseResourcePath + thumbnailResource.href;
								}
								if (contentResource) {
									sequence.contentHref = courseResourcePath + contentResource.href;
								}
								return sequence;
							});
						}
						lessonMetaData.course = course;
						lessonMetaData.data = lesson.data;
						response.success(lessonMetaData);
					} else {
						response.error({type: ErrorType.NoData});
					}
				});
			});
		},

		getStandardsMap: function(name, subjectArea, version, response) {
			var standardsDescriptionMap = {};
			Model('standardPackages').where({name: name, version: version, subjectArea: subjectArea}).get(function(standardPackageData){
				Iterator.Standard.each(standardPackageData.standards, function(standard){
					standardsDescriptionMap[standard.pedagogicalId] = standard.description;
				});
				response.success(standardsDescriptionMap);
			});
		},

		setWorkspaceAppletState: function(sessionTimestamp, appletId, stateData, response){
			var params = {userId: Module.user._user.id, sessionTimestamp: sessionTimestamp, appletId: appletId, data: stateData};
			Model('teacherAppletState').where(params).save(function(){
				response.success();
			});
		},

		getWorkspaceAppletState: function(sessionTimestamp, appletId, response){
			var params = {userId: Module.user._user.id, sessionTimestamp: sessionTimestamp, appletId: appletId};
			Model('teacherAppletState').where(params).get(function(appletState){
				response.success(appletState);
			});
		},

		setSequenceState: function (courseId, lessonCid, sequenceCid, state, response) {
			var params = {userId: Module.user._user.id, schoolId: Module.user._school.id, courseId: courseId, lessonCid: lessonCid, sequenceCid:sequenceCid},
				eventLogs = state.playerEventLogs,
				// clone state to allow state modification (set version)
				playerState = $.extend(true, {}, state.playerState);

			Model('userEventLogs').where(params).get(function(data, isDirty) {
				params.data = (isDirty) ? data.concat(eventLogs) : eventLogs;
				this.where(params).save(function() {
					Model('userSequenceState').where(params).get(function(prevState) {
						params.data = playerState;
						if (prevState && (prevState.version || prevState.version === 0)) {
							params.data.version = prevState.version;
						}
						this.where(params).save(function() {
							Module.content.flush();
							response.success();
						});
					});
				});
			});
		},

		getSequenceState: function (courseId, lessonCid, sequenceCid, response) {
			Model('userSequenceState')
				.where({userId: Module.user._user.id, schoolId: Module.user._school.id, courseId: courseId, lessonCid: lessonCid, sequenceCid:sequenceCid})
				.get(function(state){
					// clean the version property from state
					if (state) { delete state.version; }
					response.success(state);
				});
		},

		flush: function(response) {
			var params = {userId: Module.user._user.id},
				user_state_objects = [],
				user_state_metadata = [];

			Logger.d('content', 'start flushing sequence states for userId: $$', Module.user._user.id);

			Model('userEventLogs').where(params).getLocal(function(eventItems){
				Model('userSequenceState').where(params).getLocal(function(userStates) {
					for (var state in userStates) {
						var user_state_object = {
							playerState: userStates[state].data,
							playerEventLogs: []
						};
						for (var eventItem in eventItems) {
							if ((eventItems[eventItem].sequenceCid === userStates[state].sequenceCid) &&
								(eventItems[eventItem].lessonCid === userStates[state].lessonCid) &&
								(eventItems[eventItem].courseId === userStates[state].courseId)) {
								user_state_object.playerEventLogs = eventItems[eventItem].data;
								var newEventParams = eventItems[eventItem];
								newEventParams.data = [];
							}
						}
						user_state_objects.push(user_state_object);
						user_state_metadata.push(userStates[state]);
					}

					Logger.d('content', 'flushing sequence states: $$', user_state_objects);

					this.flush(user_state_objects, user_state_metadata,
						function(success) {
							if (success) {
								Model("userEventLogs").where(params).clear();
							}
							if (response && response.success) {response.success();}
						}
					);
				});
			});
		},

		flushAssessment: function(response) {
			var params = {userId: Module.user._user.id},
				statesArray = [],
				statesMetaData = [];
			Logger.d('content', 'start flushing assessment sequence states for userId: $$', Module.user._user.id);

			Model('userAssessmentSequenceScore').where(params).getLocal(function(assessmentUserScores){
				Model('userAssessmentSequenceState').where(params).getLocal(function(assessmentUserStates){

					for (var stateKey in assessmentUserStates) {
						for (var scoreKey in assessmentUserScores) {
							if ((assessmentUserStates[stateKey].assessmentInstanceId === assessmentUserScores[scoreKey].assessmentInstanceId) &&
								(assessmentUserStates[stateKey].sequenceCid === assessmentUserScores[scoreKey].sequenceCid) &&
								(assessmentUserStates[stateKey].courseId === assessmentUserScores[scoreKey].courseId)) {
								statesArray.push({
									playerState: assessmentUserStates[stateKey].data,
									sequenceScores: assessmentUserScores[scoreKey].data
								});
								statesMetaData.push(assessmentUserStates[stateKey]);
							}
						}
					}

					Logger.d('content', 'flushing assessment sequence states: $$', statesArray);
					this.flush(statesArray, statesMetaData, function(){
						if (response) {
							response.success();
						}
					});
				});
			});
		},

		getAssessmentContent: function(courseId, assessmentCid, response) {
			var assessmentKey = {courseId: courseId, assessmentCid: assessmentCid},
				courseKey = {courseId: courseId},
				assessmentData;

			Model('course').where(courseKey).get(function(course) {
				if (!course) {
					return response.success(null);
				}
				Model('assessment').where(assessmentKey).get(function(assessment) {
					if (!assessment) {
						return response.success(null);
					}
					// get assessment meta data from course
					Iterator.Assessment.each(course.data.toc, function(assessment){
						if (assessment.cid === assessmentCid) {
							assessmentData = assessment;
						}
					});
					course.assessment = assessment;
					course.assessmentData = assessmentData;
					response.success(course);
				});
			});
		},

		setAssessmentSequenceState: function(assessmentInstanceId, sequenceCid, state, response) {
			var params = { userId: Module.user._user.id, assessmentInstanceId: assessmentInstanceId, sequenceCid: sequenceCid},
				sequenceScores = $.extend(true, {}, state.sequenceScores),
				playerState = $.extend(true, {}, state.playerState);

			if (isEmptyArray(sequenceScores.tasksScore)) {
				Model('userAssessmentSequenceState').where(params).get(function(prevState){
					params.data = playerState;
					if (prevState && (prevState.version || prevState.version === 0)) {
						params.data.version = prevState.version;
					}
					this.where(params).save(function(){
						// flushing assessment states
						// Module.content.flushAssessment();
						response.success();
					});
				});
			} else {
				params.data = sequenceScores;
				Model('userAssessmentSequenceScore').where(params).save(function(){
					Model('userAssessmentSequenceState').where(params).get(function(prevState){
						params.data = playerState;
						if (prevState && (prevState.version || prevState.version === 0)) {
							params.data.version = prevState.version;
						}
						this.where(params).save(function(){
							response.success();
						});
					});
				});
			}
		},

		getAssessmentSequenceState: function(assessmentInstanceId, sequenceCid, response) {
			var params = { userId: Module.user._user.id, assessmentInstanceId: assessmentInstanceId, sequenceCid: sequenceCid};
			Model('userAssessmentSequenceState').where(params).get(function(state){
				// clean the version property from state
				if (state) { delete state.version; }
				response.success(state);
			});
		},

		submitAssessment: function(assessmentInstanceId, response) {
			Server.save('rest/assessmentUserState/submit', {
				data: {
					userId: Module.user._user.id,
					assessmentInstanceId: assessmentInstanceId,
					submittedTime: getTime()
				}
			},{
				success: response.success,
				offline: function(){response.error({type: ErrorType.ServerOffline});}
			});
		},

		getAnsweredAssessmentTasks: function(assessmentInstanceId, response) {
			var params = {userId: Module.user._user.id, assessmentInstanceId: assessmentInstanceId};
			var result = [];
			Model('userAssessmentSequenceScore').where(params).getLocal(function(scoreItems){
				scoreItems = scoreItems || [];
				for (var i = 0; i < scoreItems.length; i++) {
					if (scoreItems[i].data && scoreItems[i].data.tasksScore) {
						for (var j = 0; j < scoreItems[i].data.tasksScore.length; j++) {
							result.push({
								taskCid: scoreItems[i].data.tasksScore[j].taskCid,
								assessmentCid: scoreItems[i].data.assessmentCid,
								score: scoreItems[i].data.tasksScore[j].automatedScore
							});
						}
					}
				}
				response.success(result);
			});
		},

		getAssessmentResults: function(assessmentInstanceId, response) {
			Model('assessmentResult')
				.where({assessmentInstanceId: assessmentInstanceId})
				.get(response.success);
		},

		getAssignedClasses: function(courseId, response) {
			var params = {userId: Module.user._user.id, role: Module.user._roleStr};
			Model("studyClasses").where(params).get(function(classes){
				Model("classStates").where({userId: Module.user._user.id}).get(function(classStates){
					var ret = [];
					for (var i = 0; i < classStates.length; i++) {
						if ((classStates[i].associated) && (classStates[i].courseId === courseId)) {
							for (var j = 0; j < classes.length; j++) {
								if (classes[j].id === classStates[i].studyClassId) {
									ret.push(classes[j]);
								}
							}
						}
					}
					response.success(ret);
				});
			});
		},

		isAssessmentPublishedScores: function(assessmentInstanceId, response) {
			var params = {userId: Module.user._user.id};
			Model("classStates").where(params).get(function(classStates) {
				for (var i = 0; i < classStates.length; i++) {
					if (classStates[i].conductedSessions) {
						for (var j = 0; j < classStates[i].conductedSessions.length; j++) {
							for (var k = 0; k < classStates[i].conductedSessions[j].conductedItems.length; k++) {
								if ((classStates[i].conductedSessions[j].conductedItems[k].assessmentInstanceId === assessmentInstanceId) &&
									(classStates[i].conductedSessions[j].conductedItems[k].publishedScores)){
									return response.success(true);
								}
							}
						}
					}
				}
				return response.success(false);
			});
		},

		associateCourse: function(courseId, classIds, response) {
			var params = {userId: Module.user._user.id};
			var self = this;
			Model('classStates').where(params).get(function(classStates) {
				for (var i = 0; i < classIds.length; i++) {
					var classFound = false;
					var classId = Number(classIds[i]);
					for (var j = 0; j < classStates.length; j++) {
						if (classStates[j].studyClassId == classId) {
							classFound = true;
							classStates[j].courseId = courseId;
							classStates[j].associated = true;
						}
					}
					if (!classFound) {
						classStates.push({
							associated: true,
							courseId: courseId,
							schoolId: Module.user._school.id,
							studyClassId: classId
						});
					}
					self.classCourses[classIds[i]+""] = null;
				}
				params.data = classStates;
				this.where(params).save(response.success);
			});
		},

		disAssociateCourse: function(courseId, classIds, response) {
			var params = {userId: Module.user._user.id};
			var self = this;
			Model('classStates').where(params).get(function(classStates){
				for (var i = 0; i < classIds.length; i++) {
					for (var j = 0; j < classStates.length; j++) {
						if (classStates[j].studyClassId === Number(classIds[i]) && (classStates[j].courseId === courseId)) {
							classStates[j].associated = false;
						}
					}
					self.classCourses[classIds[i]+""] = null;
				}
				params.data = classStates;
				this.where(params).save(response.success);
			});
		},

		getAssociatedClasses: function(courseId, response) {
			var params = {userId: Module.user._user.id};
			Model('classStates').where(params).get(function(classStates){
				var ret = [];
				for (var i = 0; i < classStates.length; i++) {
					if ((classStates[i].courseId === courseId) && (classStates[i].associated)){
						ret.push(classStates[i]);
					}
				}
				response.success(ret);
			});
		},

		getAssociations: function(response) {
			var params = {userId: Module.user._user.id};
			var ret = [];
			Model('classStates').where(params).get(function(classStates) {
				for (var i = 0; i < classStates.length; i++) {
					if (classStates[i].associated) {
						ret.push({
							studyClassId: classStates[i].studyClassId,
							courseId: classStates[i].courseId
						});
					}
				}
				response.success(ret);
			});
		},

		updateCourse: function(userCourseId, newCourseId, response) {
			var self = this;
			Server.save('rest/userlibrary/update/courses/:userCourseId/t2kcourse/:newCourseId', {
				userCourseId: userCourseId,
				newCourseId: newCourseId
			}, {
				type: 'put',
				success: function(){
					self.classCourses = [];
					Model('course').where({courseId: userCourseId}).clear();
					response.success();
				},
				error: function() {
					response.error({type: ErrorType.ServerError});
				},
				offline: function() {
					response.error({type: ErrorType.ServerOffline});
				}
			});
		},

		sendToWorkspace: function(courseId, lessonCid, sequenceCid, state, response) {
			Model('globalUserState').where({userId: Module.user._user.id}).get(function(globalUserState){
				var workObject = {
					userId: Module.user._user.id,
					schoolId: Module.user._school.id,
					studyclassId: globalUserState.rtcm.activeStudyClassId,
					sessionTimestamp: globalUserState.rtcm.timestamp,
					courseId: courseId,
					lessonCid: lessonCid,
					sequenceCid: sequenceCid,
					data: state
				};
				Server.save('rest/workspaceuserstates', {data: workObject}, {
					success: response.success,
					error: response.error,
					offline: response.error
				});
			});
		}
	};

	/*
	* Session
	*
	*/
	Module.session = {

		before_filter: function(request, response) {
			Module.auth.check_auth(function(authorized){
				if (authorized) {
					request.forward();
				} else {
					response.error({type: ErrorType.NotAuthorized});
				}
			});
		},

		startLesson: function(classId, courseId, lessonCid, sequenceCid, response) {
			var startTime = getTime();
			var classState;
			Model('classStates').where({userId: Module.user._user.id}).get(function(classStates) {
				for (var i = 0; i < classStates.length; i++) {
					if ((classStates[i].studyClassId === Number(classId)) && (classStates[i].courseId === courseId)) {
						classState = classStates[i];
						classStates[i].rtcmSession = {
							sessionTimestamp: startTime,
							activeLesson: {
								lessonCid: lessonCid,
								sequenceCid: sequenceCid,
								lessonStart: startTime
							},
							eyesOnTheTeacher: false
						};
						var conductedSession = {
							sessionTimestamp: startTime,
							sessionEndTime  : 0,
							conductedItems: [{
								type	: "lesson",
								courseId: courseId,
								lessonCid :lessonCid
							}]
						};
						if (classStates[i].conductedSessions) {
							classStates[i].conductedSessions.push(conductedSession);
						} else {
							classStates[i].conductedSessions = [conductedSession];
						}
					}
				}
				this.where({userId: Module.user._user.id, data: classStates}).save(function(){
					Model('studyClasses').where({userId: Module.user._user.id, role: Module.user._roleStr}).get(function(classes){
						for (var i = 0; i < classes.length; i++) {
							if (classes[i].id === classState.studyClassId) {
								return response.success({
									timestamp: startTime,
									studyClass: classes[i],
									classState: classState,
									lessonCid: lessonCid,
									courseId: courseId,
									sequenceCid: sequenceCid
								});
							}
						}
					});
				});
			});
		},

		stopSession: function(response) {
			var endTime = getTime();
			var rtcmSession;
			var classState;
			var sessionObject;
			Model('classStates').where({userId: Module.user._user.id}).get(function(classStates) {
				for (var i = 0; i < classStates.length; i++) {
					if (classStates[i].rtcmSession) {
						rtcmSession = classStates[i].rtcmSession;
						classState = classStates[i];
						for (var j = 0; j < classStates[i].conductedSessions.length; j++) {
							if (classStates[i].conductedSessions[j].sessionTimestamp === classStates[i].rtcmSession.sessionTimestamp) {
								classStates[i].conductedSessions[j].sessionEndTime = endTime;
								if (classStates[i].conductedSessions[j].conductedItems[0].type === "assessment") {
									classStates[i].conductedSessions[j].conductedItems[0].endTime = endTime;
									classStates[i].conductedSessions[j].conductedItems[0].publishedScores = false;
								}
							}
						}
						sessionObject = {
							assessmentInstanceId: (classState.rtcmSession.activeAssessment) ? classState.rtcmSession.activeAssessment.assessmentInstanceId : null,
							timestamp: classState.rtcmSession.sessionTimestamp,
							classState: classState,
							courseId: classState.courseId,
							lessonCid: (classState.rtcmSession.activeLesson) ? classState.rtcmSession.activeLesson.lessonCid : null,
							sequenceCid: (classState.rtcmSession.activeLesson) ? classState.rtcmSession.activeLesson.sequenceCid : null,
							assessmentCid: (classState.rtcmSession.activeAssessment) ? classState.rtcmSession.activeAssessment.assessmentCid : null
						};
						classStates[i].rtcmSession = null;
						break;
					}
				}
				this.where({userId: Module.user._user.id, data: classStates}).save(function(){
					response.success(sessionObject);
				});
				Model('teacherAppletState').clear();
			});
		},

		startAssessment: function(classId, courseId, assessmentCid, response) {
			var assessmentInstanceId = generateUID();
			var classState;
			var startTime = getTime();
			Model('classStates').where({userId: Module.user._user.id}).get(function(classStates) {
				for (var i = 0; i < classStates.length; i++) {
					if ((classStates[i].studyClassId === Number(classId)) && (classStates[i].courseId === courseId)) {
						classState = classStates[i];
						classStates[i].rtcmSession = {
							sessionTimestamp: startTime,
							activeAssessment: {
								assessmentInstanceId: assessmentInstanceId,
								assessmentCid: assessmentCid,
								assessmentStart: startTime
							},
							eyesOnTheTeacher: false
						};
						var conductedSession = {
							sessionTimestamp: startTime,
							sessionEndTime  : 0,
							conductedItems: [{
								type	: "assessment",
								courseId: courseId,
								assessmentInstanceId: assessmentInstanceId,
								startTime: startTime,
								endTime  : 0,
								publishedScores: false,
								assessmentCid: assessmentCid
							}]
						};
						if (classStates[i].conductedSessions) {
							classStates[i].conductedSessions.push(conductedSession);
						} else {
							classStates[i].conductedSessions = [conductedSession];
						}
					}
				}
				this.where({userId: Module.user._user.id, data: classStates}).save(function(){
					Model('studyClasses').where({userId: Module.user._user.id, role: Module.user._roleStr}).get(function(classes){
						for (var i = 0; i < classes.length; i++) {
							if (classes[i].id === classState.studyClassId) {
								return response.success({
									timestamp: startTime,
									studyClass: classes[i],
									classState: classState,
									courseId: courseId,
									assessmentCid: assessmentCid,
									assessmentInstanceId: assessmentInstanceId
								});
							}
						}
					});
				});
			});
		},

		joinAssessment: function(assessmentInstanceId, response) {
			Server.save('rest/assessmentUserState/join', {
				data: {
					userId: Module.user._user.id,
					assessmentInstanceId: assessmentInstanceId
				}
			},{
				success: function() {
					response.success();
				},
				offline: function() {
					response.error({type: ErrorType.ServerOffline});
				}
			});
		},

		attention: function(activate, response) {
			Model('classStates').where({userId: Module.user._user.id}).get(function(states){
				for (var i = 0; i < states.length; i++) {
					if (states[i].rtcmSession) {
						states[i].rtcmSession.eyesOnTheTeacher = activate;
					}
				}
				this.where({userId: Module.user._user.id, data: states}).save(response.success);
			});
		},

		getActiveLessonStatistics: function(response) {
			var params = {userId: Module.user._user.id, schoolId: Module.user._school.id};
			Module.user.getActiveLessonSession({
				success: function(session) {
					if (session) {
						params.classId = session.studyClass.id;
						params.timestamp = session.timestamp;
						params.lessonCid = session.lessonCid;
						params.courseId = session.courseId;
						Model('lessonStatistics').where(params).get(response.success);
					} else {
						response.error({type: ErrorType.NoData});
					}
				},
				error: response.error
			});
		}
	};

	Module.notes = {

		before_filter: function(request, response) {
			Module.auth.check_auth(function(authorized){
				if (authorized) {
					request.forward();
				} else {
					response.error({type: ErrorType.NotAuthorized});
				}
			});
		},

		getNotes: function(courseId, lessonCid, response) {
			Model('notes').where({courseId: courseId, lessonCid: lessonCid}).get(function(result){
				response.success((result && result.notes) ? result.notes : []);
			});
		}
	};

	Module.net = {
		isOnline: function(response) {
			Server.isOnline(response.success);
		}
	};

	Module.notification = {

		_observers: null,

		addObserver: function (observer, method, notificationType, response) {
			if (this._observers === null) {
				this._observers = {};
			}
			if (typeof(this._observers[notificationType]) === 'undefined') {
				this._observers[notificationType] = [];
			}
			this._observers[notificationType].push({method: method, observer: observer});
			if (response && response.success) {
				response.success();
			}
		},

		trigger: function(notificationType, object) {
			if ((this._observers) && (this._observers[notificationType])){
				for (var i = 0; i < this._observers[notificationType].length; i++) {
					this._observers[notificationType][i].method.apply(this._observers[notificationType][i].observer, [object]);
				}
			}
		}
	};

	/*
	* Module DB
	* (should be removed)
	*/
	Module.db = {
		getDB: function(response) {
			response.success(DB.getHandler());
		}
	};

	Module.server = {

		casService: null,
		casWebappUrl: null,

		initData: function(response) {
			var self = this;
			Model('loginData').where({name: 'logindata'}).get(function(loginData) {
				if (loginData) {
					self.casService = loginData.casService;
					self.casWebappUrl = loginData.casWebappUrl;
					response.success(loginData);
				} else {
					response.error({type: ErrorType.NoData});
				}
			});
		}
	};

	/*
	* Api Public
	*
	*/
	var T2kApi = {
		exec: exec
	};

	/* initialize */
	initialize();
});
