/**
 * @file T2K API Header file.
 * @author Elad Yarkoni <elad.yarkoni@timetoknow.com>
 */
(function(global){

	var _api = null;

	var _api_list = {
		'html5': { path: 't2kapi', readyEvent: 't2kapi:ready'}
	};

	var exec = function(success, error, module, method, parameters) {
		_api.exec(success, error, module, method, parameters);
	};

	/**
	 * T2K Javascript Middleware.
	 * @author Elad Yarkoni
	 * @namespace T2K
	 * @description T2K Javascript middleware global object.
	 * @global
	 */
	global.T2K = global.T2K || {
		/** 
		 * T2K Api
		 * @namespace T2K
		 * @memberof T2K
		 */
		api: {
			/**
			* Load t2k api.
			* @memberof T2K.api
			* @instance
			* @param {string} name - The name of the t2k api to load.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {Object} t2k api object
			* @example
			* T2K.api.load('html5', function(api){
			*	// api is loaded...	
			* })
			*/
			load: function (name, success, error) {
				if (_api_list[name]) {
					require([_api_list[name].path]);
					document.addEventListener(_api_list[name].readyEvent,function(evt){
						_api = evt.data.api;
						success();
					},false);
				} else {
					error("api is not found");
				}
			}
		},

		/** 
		 * T2K user
		 * @namespace user
		 * @memberof T2K
		 */
		user: {

			/**
			* Login to LMS server.
			* @memberof T2K.user
			* @instance
			* @param {string} user - Username.
			* @param {string} password - Password.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {AppInitData}
			* @example
			* T2K.user.login('user', 'password', function(appInitData){
			*	// application init data...
			* })
			*/
			login: function (user, password, success, error) {
				exec(success, error, "user", "login", [user, password]);
			},

			changePassword: function(username, oldpassword, newpassword, success, error) {
				exec(success, error, "user", "changePassword", [username, oldpassword, newpassword]);
			},

			/**
			* Logout from LMS server
			* @memberof T2K.user
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.user.logout(function(){
			*	// after logout actions...
			* })
			*/
			logout: function (success, error) {
				exec(success, error, "user", "logout", []);
			},

			/**
			* Get study classes for the current user.
			* @memberof T2K.user
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {StudyClasses}
			* @example
			* T2K.user.getStudyClasses(function(studyClasses){
			*	for (var key in studyClasses) {
			*		// do something...
			*	}
			* })
			*/
			getStudyClasses: function (success, error) {
				exec(success, error, "user", "getStudyClasses", []);
			},

			initData: function(success, error) {
				exec(success, error, "user", "initData", []);
			},

			/**
			* Get user configurations
			* @memberof T2K.user
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {Object}
			* @example
			* T2K.user.getConfigurations(function(configurations){
			*	 alert('user id is: ' + configurations.user.id);
			* })
			*/
			getConfigurations: function(success, error) {
				exec(success, error, "user", "getConfigurations", []);
			},

			/**
			* Get active lesson session for the user.
			* @memberof T2K.user
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {LessonSession}
			* @example
			* T2K.user.getActiveLessonSession(function(session){
			*	 
			* })
			*/
			getActiveLessonSession: function (success, error) {
				exec(success, error, "user", "getActiveLessonSession", []);
			},

			/**
			* set active lesson session for the user.
			* @memberof T2K.user
			* @instance
			* @param {Number} classId - class id.
			* @param {Date} timestamp - active session timestamp (used as the session identifier).
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {LessonSession}
			* @example
			* T2K.user.setActiveLessonSession(function(lessonSession){
			*	 // user is in lesson session now.
			* })
			*/
			setActiveLessonSession: function (classId, timestamp, success, error) {
				exec(success, error, "user", "setActiveLessonSession", [classId, timestamp]);
			},

			/**
			* Get active assessment session for the user.
			* @memberof T2K.user
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {AssessmentSession}
			* @example
			* T2K.user.getActiveAssessmentSession(function(session){
			*	 
			* })
			*/
			getActiveAssessmentSession: function (success, error) {
				exec(success, error, "user", "getActiveAssessmentSession", []);
			},

			/**
			 * Leave active session
			 * @memberof T2K.user
			 * @instance
			 * @param  {successCallback} success [description]
			 * @param  {errorCallback} error   [description]
			 */
			leaveSession: function(success, error) {
				exec(success, error, "user", "leaveSession", []);
			},

			/**
			* set active assessment session for the user.
			* @memberof T2K.user
			* @instance
			* @param {Number} classId - class id.
			* @param {Date} timestamp - active session timestamp (used as the session identifier).
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {AssessmentSession}
			* @example
			* T2K.user.setActiveLessonSession(function(lessonSession){
			*	 // user is in lesson session now.
			* })
			*/
			setActiveAssessmentSession: function (classId, timestamp, success, error) {
				exec(success, error, "user", "setActiveAssessmentSession", [classId, timestamp]);
			},

			/**
			* get all available sessions for the student.
			* @memberof T2K.user
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns Array of {AssessmentSession|LessonSession}
			* @example
			* T2K.user.getAvailableSessions(function(sessions){
			*	 // all available sessions...
			* })
			*/
			getAvailableSessions: function (success, error) {
				exec(success, error, "user", "getAvailableSessions", []);
			},

			/**
			* get activities for student by study class.
			* @memberof T2K.user
			* @instance
			* @param {Number} classId - study class id.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {Array}
			* @example
			* T2K.user.getActivities(34, function(activities){
			*	 // all student activities
			* })
			*/
			getActivities: function(classId, success, error) {
				exec(success, error, "user", "getActivities", [classId]);
			},

			/**
			* get conducted assessment for a class sorted date from last conducted to olders.
			* @memberof T2K.user
			* @instance
			* @param {Number} classId - study class id.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {Array}
			* @example
			* T2K.user.getConductedAssessments(34, function(assessments){
			*	 // all conducted assessments
			* })
			*/
			getConductedAssessments: function(classId, success, error) {
				exec(success, error, "user", "getConductedAssessments", [classId]);
			},

			/**
			* get conducted lessons for a class sorted date from last conducted to olders.
			* @memberof T2K.user
			* @instance
			* @param {Number} classId - study class id.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {Array}
			* @example
			* T2K.user.getConductedLessons(34, function(lessons){
			*	 // all conducted lessons
			* })
			*/
			getConductedLessons: function(classId, success, error) {
				exec(success, error, "user", "getConductedLessons", [classId]);
			},

			/**
			 * Get conducted sessions for a class
			 * @param  {Number} classId
			 * @param  {successCallback} success
			 * @param  {errorCallback} error
			 * @return {Array}
			 */
			getConductedSessions: function(classId, success, error) {
				exec(success, error, "user", "getConductedSessions", [classId]);
			}
		},

		/** 
		 * T2K content
		 * @namespace content
		 * @memberof T2K
		 */
		content: {

			/** setWorkspaceAppletState - save applet state for current RTCM session
			 * a teacher API
			 * @memberof T2K.content
			 * @param sessionTimestamp
			 * @param appletId
			 * @param stateData
			 * @param success
			 * @param error
			 * @example
			 * T2K.content.setWorkspaceAppletState(123456789, 'ABCDEFG-123456',
			 * {"currentStage":1,"stagesData":{"1":"some text","2":"","3":"","4":"","5":""} function(){
			 *
			 * })
			 */
			setWorkspaceAppletState: function(sessionTimestamp, appletId, stateData, success, error){
				exec(success, error, "content", "setWorkspaceAppletState", [sessionTimestamp, appletId, stateData]);
			},

			/**
			 * getWorkspaceAppletState - returns applet state for the current RTCM session
			 * a teacher API
			 * @memberof T2K.content
			 * @param sessionTimestamp
			 * @param appletId
			 * @param success
			 * @param error
			 */
			getWorkspaceAppletState: function(sessionTimestamp, appletId, success, error){
				exec(success, error, "content", "getWorkspaceAppletState", [sessionTimestamp, appletId]);
			},

			/**
			* get course json for a class by class id.
			* @memberof T2K.content
			* @instance
			* @param {Number} classId - study class id.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {Course}
			* @example
			* T2K.content.getCourseByClass(34, function(course){
			*	 
			* })
			*/
			getCourseByClass: function (classId, success, error) {
				exec(success, error, "content", "getCourseByClass", [classId]);
			},

			getCourse: function(courseId, success, error) {
				exec(success, error, "content", "getCourse", [courseId]);
			},

			getLesson: function(courseId, lessonCid, success, error) {
				exec(success, error, "content", "getLesson", [courseId, lessonCid]);
			},

			/**
			* get lesson content json by courseId and lessonCid.
			* @memberof T2K.content
			* @instance
			* @param {String} courseId - course id.
			* @param {String} lessonCid - lesson cid.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {Lesson}
			* @example
			* T2K.content.getLessonContent(courseId, lessonCid, function(lesson){
			*	 
			* })
			*/
			getLessonContent: function (courseId, lessonCid, success, error) {
				exec(success, error, "content", "getLessonContent", [courseId, lessonCid]);
			},

			/**
			* get lesson content for student json by classId, courseId and lessonCid.
			* @memberof T2K.content
			* @instance
			* @param {String} courseId - course id.
			* @param {String} lessonCid - lesson cid.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {Lesson}
			* @example
			* T2K.content.getLessonContentForStudent(courseId, lessonCid, function(lesson){
			*	 
			* })
			*/
			getLessonContentForStudent: function (classId, courseId, lessonCid, success, error) {
				exec(success, error, "content", "getLessonContentForStudent", [classId, courseId, lessonCid]);
			},

			/**
			* get assessment content json by courseId and assessmentCid.
			* @memberof T2K.content
			* @instance
			* @param {String} courseId - course id.
			* @param {String} assessmentCid - assessment cid.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {Assessment}
			* @example
			* T2K.content.getAssessmentContent(courseId, assessmentCid, function(assessment){
			*	 
			* })
			*/
			getAssessmentContent: function(courseId, assessmentCid, success, error) {
				exec(success, error, "content", "getAssessmentContent", [courseId, assessmentCid]);
			},

			/**
			* Save user working state for a sequence.
			* @memberof T2K.content
			* @instance
			* @param {String} courseId - course id.
			* @param {String} lessonCid - lesson cid.
			* @param {String} sequenceCid - sequence cid.
			* @param {UserSequenceState} state - player state.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.content.setSequenceState(courseId, lessonCid, sequenceCid, state, function(){
			*	// state is saved.
			* })
			*/
			setSequenceState: function (courseId, lessonCid, sequenceCid, state, success, error) {
				exec(success, error, "content", "setSequenceState", [courseId, lessonCid, sequenceCid, state]);
			},

			/**
			* get user working state for a sequence.
			* @memberof T2K.content
			* @instance
			* @param {String} courseId - course id.
			* @param {String} lessonCid - lesson cid.
			* @param {String} sequenceCid - sequence cid.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {UserSequenceState}
			* @example
			* T2K.content.getSequenceState(courseId, lessonCid, sequenceCid, function(state){
			*	Player.setState(state);
			*	...
			* })
			*/
			getSequenceState: function (courseId, lessonCid, sequenceCid, success, error) {
				exec(success, error, "content", "getSequenceState", [courseId, lessonCid, sequenceCid]);
			},

			/**
			* Save user working state for a sequence in assessment.
			* @memberof T2K.content
			* @instance
			* @param {String} assessmentInstanceId - assessment instance id.
			* @param {String} sequenceCid - sequence cid.
			* @param {UserAssessmentSequenceState} state - player state.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.content.setAssessmentSequenceState(assessmentInstanceId, sequenceCid, state, function(){
			*	// state is saved.
			* })
			*/
			setAssessmentSequenceState: function (assessmentInstanceId, sequenceCid, state, success, error) {
				exec(success, error, "content", "setAssessmentSequenceState", [assessmentInstanceId, sequenceCid, state]);
			},

			/**
			* Save user working state for a sequence in assessment.
			* @memberof T2K.content
			* @instance
			* @param {String} assessmentInstanceId - assessment instance id.
			* @param {String} sequenceCid - sequence cid.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {UserAssessmentSequenceState}
			* @example
			* T2K.content.getAssessmentSequenceState(assessmentInstanceId, sequenceCid, function(state){
			*	Player.setState(state);
			* })
			*/
			getAssessmentSequenceState: function (assessmentInstanceId, sequenceCid, success, error) {
				exec(success, error, "content", "getAssessmentSequenceState", [assessmentInstanceId, sequenceCid]);
			},

			/**
			* Uploading all unsaved state from the client local database to server. 
			* @memberof T2K.content
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* if (backFromOfflineMode) {
			* 	content.flush();
			* }
			*/
			flush: function(success, error) {
				exec(success, error, "content", "flush", []);
			},

			/**
			* Uploading all unsaved assessments state from the client local database to server. 
			* @memberof T2K.content
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* onAssessmentSubmitted: function() {
			* 	content.flushAssessment();
			* }
			*/
			flushAssessment: function(success, error) {
				exec(success, error, "content", "flushAssessment", []);
			},

			/**
			* Submit an assessment (Student only) 
			* @memberof T2K.content
			* @instance
			* @param {String} assessmentInstanceId
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.content.submitAssessment(assessmentInstanceId, function(){
			*	// go back to homepage.
			* });
			*/
			submitAssessment: function(assessmentInstanceId, success, error) {
				exec(success, error, "content", "submitAssessment", [assessmentInstanceId]);
			},

			/**
			* Get all answered tasks for an assessment with scores.
			* @memberof T2K.content
			* @instance
			* @param {String} assessmentInstanceId
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns Array of {TaskScore}
			* @example
			* T2K.content.getAnsweredAssessmentTasks(assessmentInstanceId, function(tasks){
			*	
			* });
			*/
			getAnsweredAssessmentTasks: function(assessmentInstanceId, success, error) {
				exec(success, error, "content", "getAnsweredAssessmentTasks", [assessmentInstanceId]);
			},

			/**
			* Get Assessment class results (for teacher)
			* @memberof T2K.content
			* @instance
			* @param {String} assessmentInstanceId
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns {AssessmentResult}
			* @example
			* T2K.content.getAssessmentResults(assessmentInstanceId, function(assessmentResult){
			*	
			* });
			*/
			getAssessmentResults: function(assessmentInstanceId, success, error) {
				exec(success, error, "content", "getAssessmentResults", [assessmentInstanceId]);
			},

			/**
			 * Get Standards hashmap. Key is standard id and value is standard description
			 * @memberof T2K.content
			 * @instance
			 * @param  {String} name        	
			 * @param  {String} subjectArea
			 * @param  {String} version 
			 * @param  {successCallback} success
			 * @param  {errorCallback} error
			 * @return {StandardsMap}
			 * @example
			 * T2K.content.getStandardsMap(name, subjectArea, version, function(map){ ... })
			 */
			getStandardsMap: function(name, subjectArea, version, success, error) {
				exec(success, error, "content", "getStandardsMap", [name, subjectArea, version]);	
			},

			/**
			 * Get assigned classes for a course
			 * @param  {String} courseId Course id
			 * @param  {successCallback} success 
			 * @param  {errorCallback} error
			 * @return {Classes}
			 */
			getAssignedClasses: function(courseId, success, error) {
				exec(success, error, "content", "getAssignedClasses", [courseId]);
			},

			/**
			 * Return true if all student submitted their assessments.
			 * @param  {String} assessmentInstanceId assessment instance id
			 * @param  {successCallback} success 
			 * @param  {errorCallback} error
			 * @return {Boolean}
			 */
			isAssessmentPublishedScores: function(assessmentInstanceId, success, error) {
				exec(success, error, "content", "isAssessmentPublishedScores", [assessmentInstanceId]);
			},

			associateCourse: function(courseId, classIds, success, error) {
				exec(success, error, "content", "associateCourse", [courseId, classIds]);
			},

			disAssociateCourse: function(courseId, classIds, success, error) {
				exec(success, error, "content", "disAssociateCourse", [courseId, classIds]);
			},

			getAssociatedClasses: function(courseId, success, error) {
				exec(success, error, "content", "getAssociatedClasses", [courseId]);
			},

			getAssociations: function(success, error) {
				exec(success, error, "content", "getAssociations", []);
			},

			updateCourse: function(userCourseId, newCourseId, success, error) {
				exec(success, error, "content", "updateCourse", [userCourseId, newCourseId]);
			},

			sendToWorkspace: function(courseId, lessonCid, sequenceCid, state, success, error) {
				exec(success, error, "content", "sendToWorkspace", [courseId, lessonCid, sequenceCid, state]);
			}
		},

		/** 
		 * T2K session
		 * @namespace session
		 * @memberof T2K
		 */
		session: {

			/**
			* Start a new lesson for the class which starts with the given sequence.
			* @memberof T2K.session
			* @instance
			* @param {Number} classId
			* @param {String} courseId
			* @param {String} lessonCid
			* @param {String} sequenceCid
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.session.startLesson(classId, courseId, lessonCid, sequenceCid, function(){
			*	
			* });
			*/
			startLesson: function (classId, courseId, lessonCid, sequenceCid, success, error) {
				exec(success, error, "session", "startLesson", [classId, courseId, lessonCid, sequenceCid]);
			},

			/**
			* Start a new assessment for the class.
			* @memberof T2K.session
			* @instance
			* @param {Number} classId
			* @param {String} courseId
			* @param {String} assessmentCid
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.session.startAssessment(classId, courseId, assessmentCid, function(){
			*	
			* });
			*/
			startAssessment: function (classId, courseId, assessmentCid, success, error) {
				exec(success, error, "session", "startAssessment", [classId, courseId, assessmentCid]);
			},

			/**
			* Stop active session for the class
			* @memberof T2K.session
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.session.stopSession(function(){
			*	
			* });
			*/
			stopSession: function (success, error) {
				exec(success, error, "session", "stopSession", []);
			},

			/**
			* Join the current student user to the active assessment
			* @memberof T2K.session
			* @instance
			* @param {String} assessmentInstanceId
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.session.joinAssessment(assessmentInstanceId, function(){
			*	
			* });
			*/
			joinAssessment: function(assessmentInstanceId, success, error) {
				exec(success, error, "session", "joinAssessment", [assessmentInstanceId]);
			},

			/**
			 * Activate eyes on teacher
			 * @memberof T2K.session
			 * @instance
			 * @param  {Boolean} activate
			 * @param  {successCallback} success
			 * @param  {errorCallback} error
			 */
			attention: function(activate, success, error) {
				exec(success, error, "session", "attention", [activate]);
			},

			/**
			 * Get active lesson statistics
			 * @memberof T2K.session
			 * @instance
			 * @param  {successCallback} success
			 * @param  {errorCallback} error
			 * @return {Object}
			 */
			getActiveLessonStatistics: function(success, error) {
				exec(success, error, "session", "getActiveLessonStatistics", []);
			}
		},

		/** 
		 * T2K notes
		 * @namespace notes
		 * @memberof T2K
		 */
		notes: {

			/**
			* Get notes list for a lesson
			* @memberof T2K.notes
			* @instance
			* @param {String} courseId
			* @param {String} lessonCid
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @returns Array of {Note}
			* @example
			* T2K.notes.getNotes(courseId, lessonCid, function(notesArray){
			*	
			* });
			*/
			getNotes: function (courseId, lessonCid, success, error) {
				exec(success, error, "notes", "getNotes", [courseId, lessonCid]);
			},

			/**
			* Add a note to a lesson
			* @memberof T2K.notes
			* @instance
			* @param {String} courseId
			* @param {String} lessonCid
			* @param {Note} note
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.notes.addNote(courseId, lessonCid, note, function(){
			*	
			* });
			*/
			addNote: function (courseId, lessonCid, note, success, error) {
				exec(success, error, "notes", "addNote", [courseId, lessonCid, note]);
			},

			/**
			* Delete a note from lesson
			* @memberof T2K.notes
			* @instance
			* @param {String} courseId
			* @param {String} lessonCid
			* @param {Note} note
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.notes.deleteNote(courseId, lessonCid, note, function(){
			*	
			* });
			*/
			deleteNote: function (courseId, lessonCid, note, success, error) {
				exec(success, error, "notes", "deleteNote", [courseId, lessonCid, note]);
			}
		},

		/** 
		 * T2K net
		 * @namespace net
		 * @memberof T2K
		 */
		net: {
			/**
			* Check if server is online.
			* @memberof T2K.net
			* @instance
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.net.isOnline(function(online){
			*	if (online) { // do something} else { // do something }
			* });
			*/
			isOnline: function (success, error) {
				exec(success, error, "net", "isOnline", []);
			}
		},

		/** 
		 * T2K notification
		 * @namespace notification
		 * @memberof T2K
		 */
		notification: {
			/**
			* Add observer to API events.
			* @memberof T2K.notification
			* @instance
			* @param {Object} observer - observer instance.
			* @param {Function} method - observer handler method
			* @param {String} notificationType - Notification type to listen.
			* @param {successCallback} success - Success handler.
			* @param {errorCallback} error - Error handler.
			* @example
			* T2K.notification.addObserver(this, this.onServerOffline, 'ServerOfflineNotification', function(online){
			*	
			* });
			*/
			addObserver: function (observer, method, notificationType, success, error) {
				exec(success, error, "notification", "addObserver", [observer, method, notificationType]);
			}
		},

		/** 
		 * T2K db (Depracated!)
		 * @namespace db
		 * @memberof T2K
		 */
		db: {
			/**
			* Returns API DB handler.
			* @memberof T2K.db
			* @instance
			* @param {successCallback} success - Success handler.
			* @deprecated
			* @example
			* T2K.db.getDB(function(dbHandler){
			*	
			* });
			*/
			getDB: function(success) {
				exec(success, null, "db", "getDB", []);
			}
		},

		/** 
		 * T2K server
		 * @namespace server
		 * @memberof T2K
		 */
		server: {
			initData: function(success, error) {
				exec(success, error, "server", "initData", []);
			}
		}
	};

	/**
	 * Application initialize data
	 * @typedef {Object} AppInitData
	 * @property {Object} configurations - application configurations.
	 * @property {Object} user - user object.
	 * @property {Object} school - school object.
	 */

	 /**
	 * Study classes array
	 * @typedef {Array} StudyClasses
	 * @property {Number} id - study class id.
	 * @property {String} name - study class name.
	 * @property {String} imageURL - study class image url
	 */

	 /**
	 * Lesson session
	 * @typedef {Object} LessonSession
	 * @property {Date} timestamp - session timestamp.
	 * @property {Object} studyClass - study class object.
	 * @property {Object} classState - study class state object.
	 * @property {String} lessonCid - lesson cid.
	 * @property {String} courseId - course id.
	 * @property {String} sequenceCid - sequence cid.
	 */

	 /**
	 * Assessment session
	 * @typedef {Object} AssessmentSession
	 * @property {Date} timestamp - session timestamp.
	 * @property {Object} studyClass - study class object.
	 * @property {Object} classState - study class state object.
	 * @property {String} assessmentCid - assessment cid.
	 * @property {String} courseId - course id.
	 * @property {String} assessmentInstanceId - assessment instance id.
	 * @property {String} sequenceCid - sequence cid.
	 */

	 /**
	 * Course manifest
	 * @typedef {Object} Course
	 */

	 /**
	 * Lesson content json
	 * @typedef {Object} Lesson
	 */

	 /**
	 * Assessment content json
	 * @typedef {Object} Assessment
	 */

	 /**
	 * User sequence state.
	 * @typedef {Object} UserSequenceState
	 * @property {Object} playerEventLogs
	 * @property {Object} playerState
	 */

	 /**
	 * User assessment sequence state.
	 * @typedef {Object} UserAssessmentSequenceState
	 * @property {Object} sequenceScores
	 * @property {Object} playerState
	 */

	 /**
	 * Answered task with score
	 * @typedef {Object} TaskScore
	 * @property {String} taskCid
	 * @property {String} assessmentCid
	 * @property {Number} score
	 */

	 /**
	 * The Assessment summary results for the class with score average.
	 * @typedef {Object} AssessmentResult
	 */

	 /**
	 * Note object.
	 * @typedef {Object} Note
	 */

	/**
	 * T2k API success callback.
	 * @callback successCallback
	 * @returns {object} responseObject
	 */
	
	/**
	 * Standards map, Key is standard id and value is standard description.
	 * @typedef {Object} StandardsMap
	 */

	/**
	* T2k API error callback
	* @callback errorCallback
	* @returns {object} errorObject
	*/
})(window);