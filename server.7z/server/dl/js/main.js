require.config( {

	baseUrl: '',

	paths: {
		
		/* libs */
		jquery: 'js/libs/jquery/jquery',
		
		/* dl simulator host */
		dlhost: 'js/dlhost',

		/* dl player */
		player: 'player'
		
	}

} ) ;

require( [ "dlhost" ], function( dlhost ) {
	
	window.harta={};
	
	window.echoForKey =  function(key){
		var tmp = harta[key];
		delete harta[key];
		return tmp;
	};


	window.callback = function(res,functionName){ 

		var tmp =JSON.stringify(res);

		var key = Math.floor(Math.random()*701)+101;
		harta[key] = tmp;
	//trigger ios event
		var iframe = document.createElement('IFRAME');

		iframe.setAttribute('src', 'http://js-call;:;:;'+ functionName +';:;:;'+key);
		
		document.documentElement.appendChild(iframe);
		
		iframe.parentNode.removeChild(iframe);
		
		iframe = null;
		
	};

	window.callDlAgent = function(config){
		callback(config,'dlapi:');
//			if( config.success ) {
//				config.success() ;
 //      		}
	};
	
	window.dlhost = new dlhost() ;
	
	window.callback('YES','loadded:') ;
	
});
